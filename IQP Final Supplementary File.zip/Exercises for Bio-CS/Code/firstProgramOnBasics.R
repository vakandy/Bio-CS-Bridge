# create print statment to say "Hello World"
print("Hello World")


#Create and aaaign number to the "x" variable 
x <- 4


#Create and aaaign number to the "y" variable 
y <- 2


# Addition of "x" and "y" variables
x + y


# Lists all built in datasets in R
data()


# Help command
help()


# Get info on trees dataset
help(trees)


# Get the dataframe on trees dataset
head(trees)


# Count number of Trees there are in trees dataset
nrow(trees)


# find how to find mean of a variable of the trees dataset
?mean


# Find mean of "Girth" variable of trees dataset
mean(trees$Girth)


# Find how to find mean of a variable of the trees dataset
?sd


# Find mean of "weight" variable of trees dataset
sd(trees$Girth)


# Get the summary of the dataset
summary(trees)


